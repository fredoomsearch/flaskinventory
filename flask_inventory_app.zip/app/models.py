from . import db

class Inventory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    mac_address = db.Column(db.String(50))
    serial_number = db.Column(db.String(100))
    manufacturer = db.Column(db.String(100))
    description = db.Column(db.Text)
